import os, time, threading
from datetime import date
from datetime import datetime, timezone
from flask import Flask, jsonify, render_template
import requests
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)

BASE_URL = "https://fapi.binance.com"
TOP_N = int(os.getenv("TOP_N", "20"))
MIN_SCORE = float(os.getenv("MIN_SCORE", "8.0"))
MAX_SIGNALS = int(os.getenv("MAX_SIGNALS", "10"))
TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()
REQUEST_TIMEOUT = 12
session = requests.Session()
session.headers.update({"User-Agent": "NEXORA-AI-PRO-V6/1.0"})
_last_scan = {"at": None, "signals": [], "scanned": 0, "errors": [], "status": "Not scanned"}
_scan_lock = threading.Lock()
_scheduler_started = False
_seen_signal_keys = set()
_daily_signal_count = 0
_daily_count_date = date.today()

def api_get(path, params=None):
    r = session.get(BASE_URL + path, params=params, timeout=REQUEST_TIMEOUT)
    r.raise_for_status()
    return r.json()

def ema(values, period):
    if len(values) < period:
        return None
    k = 2 / (period + 1)
    result = sum(values[:period]) / period
    for value in values[period:]:
        result = value * k + result * (1-k)
    return result

def rsi(values, period=14):
    if len(values) <= period:
        return None
    gains, losses = [], []
    for i in range(1, len(values)):
        d = values[i] - values[i-1]
        gains.append(max(d, 0))
        losses.append(max(-d, 0))
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for i in range(period, len(gains)):
        avg_gain = (avg_gain*(period-1) + gains[i]) / period
        avg_loss = (avg_loss*(period-1) + losses[i]) / period
    if avg_loss == 0:
        return 100.0
    return 100 - (100 / (1 + avg_gain / avg_loss))

def atr(highs, lows, closes, period=14):
    if len(closes) <= period:
        return None
    trs = []
    for i in range(1, len(closes)):
        trs.append(max(highs[i]-lows[i], abs(highs[i]-closes[i-1]), abs(lows[i]-closes[i-1])))
    return sum(trs[-period:]) / period

def fetch_candles(symbol, interval, limit=120):
    raw = api_get("/fapi/v1/klines", {"symbol": symbol, "interval": interval, "limit": limit})
    # Ignore the currently forming candle.
    raw = raw[:-1]
    return {
        "open": [float(x[1]) for x in raw],
        "high": [float(x[2]) for x in raw],
        "low": [float(x[3]) for x in raw],
        "close": [float(x[4]) for x in raw],
        "volume": [float(x[5]) for x in raw],
    }

def structure_bias(c):
    highs, lows, closes = c["high"], c["low"], c["close"]
    if len(closes) < 30:
        return "neutral", False, False
    recent_high = max(highs[-21:-1])
    recent_low = min(lows[-21:-1])
    bos_up = closes[-1] > recent_high
    bos_down = closes[-1] < recent_low
    # A simple swing progression proxy, not a full discretionary ICT structure engine.
    hh = max(highs[-10:]) > max(highs[-20:-10])
    hl = min(lows[-10:]) > min(lows[-20:-10])
    lh = max(highs[-10:]) < max(highs[-20:-10])
    ll = min(lows[-10:]) < min(lows[-20:-10])
    if bos_up or (hh and hl):
        return "bullish", bos_up, False
    if bos_down or (lh and ll):
        return "bearish", False, bos_down
    return "neutral", False, False

def liquidity_sweep(c, direction):
    highs, lows, closes = c["high"], c["low"], c["close"]
    if len(closes) < 25:
        return False
    prior_low = min(lows[-21:-1])
    prior_high = max(highs[-21:-1])
    if direction == "LONG":
        return lows[-1] < prior_low and closes[-1] > prior_low
    return highs[-1] > prior_high and closes[-1] < prior_high

def fvg_alignment(c, direction):
    h, l = c["high"], c["low"]
    if len(h) < 4:
        return False
    # Three-candle imbalance proxy.
    if direction == "LONG":
        return l[-1] > h[-3]
    return h[-1] < l[-3]

def volume_ratio(c):
    v = c["volume"]
    if len(v) < 21 or sum(v[-21:-1]) == 0:
        return 0
    return v[-1] / (sum(v[-21:-1]) / 20)

def analyze_symbol(symbol):
    c15 = fetch_candles(symbol, "15m")
    time.sleep(0.08)
    c1h = fetch_candles(symbol, "1h")
    time.sleep(0.08)
    c4h = fetch_candles(symbol, "4h")

    close15, close1h, close4h = c15["close"], c1h["close"], c4h["close"]
    if min(len(close15), len(close1h), len(close4h)) < 40:
        raise ValueError("Insufficient candle history")

    e9_1h, e21_1h = ema(close1h, 9), ema(close1h, 21)
    e9_4h, e21_4h = ema(close4h, 9), ema(close4h, 21)
    e9_15, e21_15 = ema(close15, 9), ema(close15, 21)
    rsi15, rsi1h = rsi(close15), rsi(close1h)
    atr15 = atr(c15["high"], c15["low"], close15)
    if not all(x is not None for x in [e9_1h,e21_1h,e9_4h,e21_4h,e9_15,e21_15,rsi15,rsi1h,atr15]):
        raise ValueError("Indicator calculation unavailable")

    # Direction is selected by higher-timeframe alignment first.
    long_htf = e9_1h > e21_1h and e9_4h > e21_4h
    short_htf = e9_1h < e21_1h and e9_4h < e21_4h
    if long_htf:
        direction = "LONG"
    elif short_htf:
        direction = "SHORT"
    else:
        return None

    score = 0.0
    reasons = []
    # Multi-timeframe trend: 2.5 points.
    score += 2.5
    reasons.append("1H + 4H trend aligned")
    if (direction == "LONG" and e9_15 > e21_15) or (direction == "SHORT" and e9_15 < e21_15):
        score += 1.0
        reasons.append("15M momentum confirms")

    bias, bos_up, bos_down = structure_bias(c1h)
    if (direction == "LONG" and bias == "bullish") or (direction == "SHORT" and bias == "bearish"):
        score += 1.5
        reasons.append("Market structure supports direction")
    if (direction == "LONG" and bos_up) or (direction == "SHORT" and bos_down):
        score += 0.5
        reasons.append("Recent structure break")

    if liquidity_sweep(c15, direction):
        score += 1.5
        reasons.append("Liquidity sweep + reclaim")
    if fvg_alignment(c15, direction):
        score += 1.0
        reasons.append("15M imbalance alignment")

    vr = volume_ratio(c15)
    if vr >= 1.2:
        score += 1.0
        reasons.append("Volume expansion")

    if direction == "LONG" and 48 <= rsi15 <= 68 and rsi1h >= 48:
        score += 1.0
        reasons.append("RSI momentum healthy")
    elif direction == "SHORT" and 32 <= rsi15 <= 52 and rsi1h <= 52:
        score += 1.0
        reasons.append("RSI momentum healthy")

    # Cap score at 10. Do not create signals below threshold.
    score = round(min(score, 10.0), 1)
    if score < MIN_SCORE:
        return None

    entry = close15[-1]
    stop_distance = max(atr15 * 1.35, entry * 0.002)
    if direction == "LONG":
        sl = entry - stop_distance
        tp1, tp2, tp3 = entry + stop_distance, entry + stop_distance*2, entry + stop_distance*3
    else:
        sl = entry + stop_distance
        tp1, tp2, tp3 = entry - stop_distance, entry - stop_distance*2, entry - stop_distance*3

    def fmt(x):
        return f"{x:.8f}".rstrip("0").rstrip(".") if x < 1 else f"{x:.4f}".rstrip("0").rstrip(".")

    return {
        "symbol": symbol, "direction": direction, "rating": score,
        "entry": fmt(entry), "sl": fmt(sl),
        "tp1": fmt(tp1), "tp2": fmt(tp2), "tp3": fmt(tp3),
        "rsi15": round(rsi15,1), "rsi1h": round(rsi1h,1),
        "volume_ratio": round(vr,2), "reasons": reasons,
        "timeframes": "15M / 1H / 4H",
        "generated_at": datetime.now(timezone.utc).isoformat()
    }

def send_telegram(signal):
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        return False
    msg = (
        f"🚀 NEXORA AI PRO V6\\n"
        f"{signal['symbol']} | {signal['direction']}\\n"
        f"AI Rating: {signal['rating']}/10\\n"
        f"Entry: {signal['entry']}\\n"
        f"TP1: {signal['tp1']}\\nTP2: {signal['tp2']}\\nTP3: {signal['tp3']}\\n"
        f"SL: {signal['sl']}\\n"
        f"Timeframes: {signal['timeframes']}\\n"
        f"Risk guide: 1% account risk maximum\\n"
        f"Educational signal; verify before trading."
    )
    try:
        requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage",
            json={"chat_id": TELEGRAM_CHAT_ID, "text": msg},
            timeout=10
        ).raise_for_status()
        return True
    except requests.RequestException:
        return False

def run_scan():
    global _daily_signal_count, _daily_count_date
    with _scan_lock:
        today = date.today()
        if today != _daily_count_date:
            _daily_count_date = today
            _daily_signal_count = 0
        errors, found = [], []
        try:
            info = api_get("/fapi/v1/exchangeInfo")
            tradable = {
                x["symbol"] for x in info["symbols"]
                if x.get("status") == "TRADING"
                and x.get("contractType") == "PERPETUAL"
                and x.get("quoteAsset") == "USDT"
            }
            tickers = api_get("/fapi/v1/ticker/24hr")
            ranked = sorted(
                [t for t in tickers if t["symbol"] in tradable],
                key=lambda t: float(t.get("quoteVolume", 0)),
                reverse=True
            )[:TOP_N]
            scanned = 0
            for ticker in ranked:
                symbol = ticker["symbol"]
                try:
                    scanned += 1
                    item = analyze_symbol(symbol)
                    if item:
                        item["quote_volume_24h"] = round(float(ticker.get("quoteVolume",0)), 0)
                        found.append(item)
                except Exception as exc:
                    errors.append(f"{symbol}: {str(exc)[:100]}")
            found.sort(key=lambda x: x["rating"], reverse=True)
            # Daily cap applies to newly alerted signals, not the number of cards shown on the dashboard.
            remaining = max(0, MAX_SIGNALS - _daily_signal_count)
            newly_alerted = []
            for item in found:
                key = (today.isoformat(), item["symbol"], item["direction"])
                if key not in _seen_signal_keys and len(newly_alerted) < remaining:
                    _seen_signal_keys.add(key)
                    newly_alerted.append(item)
            for item in newly_alerted:
                if send_telegram(item):
                    _daily_signal_count += 1
            found = found[:MAX_SIGNALS]
            _last_scan.update({
                "at": datetime.now(timezone.utc).isoformat(),
                "signals": found, "scanned": scanned, "daily_alerts_sent": _daily_signal_count,
                "daily_limit": MAX_SIGNALS, "errors": errors[:8], "status": "Completed"
            })
        except Exception as exc:
            _last_scan.update({"status": "Error", "errors": [str(exc)], "signals": []})
        return _last_scan

@app.route("/")
def home():
    return render_template("index.html", min_score=MIN_SCORE, top_n=TOP_N)

@app.route("/api/health")
def health():
    return jsonify({"ok": True, "name": "NEXORA AI PRO V6", "mode": "signals_only"})

@app.route("/api/scan", methods=["GET","POST"])
def scan():
    result = run_scan()
    return jsonify(result)

@app.route("/api/status")
def status():
    return jsonify(_last_scan)

def scheduler_loop():
    interval = max(5, int(os.getenv("SCAN_INTERVAL_MINUTES", "15"))) * 60
    # Run an initial scan after startup, then repeat at the configured interval.
    time.sleep(8)
    while True:
        try:
            run_scan()
        except Exception:
            pass
        time.sleep(interval)

def start_scheduler():
    global _scheduler_started
    if not _scheduler_started and os.getenv("ENABLE_SCHEDULER", "true").lower() == "true":
        _scheduler_started = True
        threading.Thread(target=scheduler_loop, daemon=True, name="nexora-scheduler").start()

start_scheduler()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
