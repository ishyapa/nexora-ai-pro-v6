const board = document.getElementById("signals");
const btn = document.getElementById("scanBtn");
const state = document.getElementById("scanState");
const scanTime = document.getElementById("scanTime");

function esc(v){return String(v ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function render(data){
  scanTime.textContent = data.at ? new Date(data.at).toLocaleString() : "No scan yet";
  if(!data.signals || !data.signals.length){
    board.innerHTML = `<div class="empty"><div>⌁</div><h3>NO TRADE</h3><p>No setup met the minimum confidence filter in this scan. Wait for better confluence.</p></div>`;
    return;
  }
  board.innerHTML = data.signals.map(s=>`
    <article class="signal">
      <div class="signal-top"><span class="coin">${esc(s.symbol)}</span><span class="direction ${esc(s.direction)}">${esc(s.direction)}</span><span class="rating">★ ${esc(s.rating)}/10</span></div>
      <div class="price-grid">
        <div class="price"><label>ENTRY</label><strong>${esc(s.entry)}</strong></div>
        <div class="price"><label>STOP LOSS</label><strong class="sl">${esc(s.sl)}</strong></div>
        <div class="price"><label>TAKE PROFIT 1</label><strong class="tp">${esc(s.tp1)}</strong></div>
        <div class="price"><label>TAKE PROFIT 2</label><strong class="tp">${esc(s.tp2)}</strong></div>
        <div class="price"><label>TAKE PROFIT 3</label><strong class="tp">${esc(s.tp3)}</strong></div>
        <div class="price"><label>15M RSI / VOL RATIO</label><strong>${esc(s.rsi15)} / ${esc(s.volume_ratio)}x</strong></div>
      </div>
      <div class="reasons"><b>CONFLUENCE</b><br>${(s.reasons||[]).map(x=>`<span>${esc(x)}</span>`).join("")}</div>
    </article>`).join("");
}
async function startScan(){
  btn.disabled=true;btn.textContent="SCANNING MARKET...";state.textContent="Fetching live Binance Futures market data. This may take a minute.";
  try{
    const r=await fetch("/api/scan",{method:"POST"});const data=await r.json();
    render(data);
    state.textContent=data.status==="Completed"?`Scan complete · ${data.scanned} pairs checked · ${data.signals.length} qualified signals`:`Scan error: ${(data.errors||[]).join(" | ")}`;
  }catch(e){state.textContent="Unable to complete scan. Check server connection and try again.";}
  finally{btn.disabled=false;btn.innerHTML='SCAN MARKET <b>↗</b>';}
}
fetch("/api/status").then(r=>r.json()).then(d=>{if(d.at)render(d);}).catch(()=>{});
