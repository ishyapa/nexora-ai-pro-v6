# NEXORA AI PRO V6 — Signals Edition

A responsive, self-hosted dashboard that scans Binance USDⓈ-M perpetual futures and surfaces only qualified LONG/SHORT setups.

## Features
- Public Binance Futures market data; no exchange API key required.
- Scans the top liquid USDT perpetual pairs by 24-hour quote volume.
- 15m / 1h / 4h trend alignment.
- SMC/ICT-inspired structure, liquidity sweep, and imbalance proxies.
- RSI and relative-volume filters.
- Entry, SL, TP1, TP2, TP3 and a transparent confluence list.
- Optional Telegram notifications.
- Signals-only: this project does not place, modify, or close orders.

## Important accuracy note
This is a **hybrid rules-based analysis engine**, not a trained AI model or a guarantee of profitable trades. Market-structure, liquidity-sweep and FVG checks are simplified, objective proxies. The rating is a confluence score, not a probability of winning. Backtest and paper-trade before risking money. The app deliberately returns NO TRADE when no setup meets the configured threshold.

## Run locally (Windows)
1. Install Python 3.10+ from https://www.python.org/downloads/
2. Extract the ZIP.
3. Open Command Prompt in the extracted `NEXORA_AI_PRO_V6` folder.
4. Create a virtual environment:
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   ```
5. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
6. Copy `.env.example` to `.env`. Telegram settings are optional.
7. Start:
   ```bash
   python app.py
   ```
8. Open http://127.0.0.1:5000 in Chrome.

## Run locally (Android)
The easiest option is a cloud Python host. On Android, install a Python environment such as Termux, install Python and the requirements, run `python app.py`, then open the local address shown by the environment. A cloud host is recommended for reliable 24/7 operation.

## Telegram alerts (optional)
1. Create a bot with Telegram's official `@BotFather`.
2. Get your chat ID.
3. Put the bot token and chat ID in `.env`.
4. Restart the app.
5. Press Scan Market. Qualified signals from that scan are sent to Telegram.

Never share your bot token publicly. Do not give this project Binance API keys; it does not need them.

## Configuration
Edit `.env`:
- `TOP_N=20`: number of liquid USDT perpetual pairs to inspect.
- `MIN_SCORE=8.0`: minimum confluence score.
- `MAX_SIGNALS=10`: maximum returned signals per scan.

## Before live use
- Compare signals with live charts and account for spread, fees, slippage and funding.
- Verify stop distance and position size yourself.
- A 1% account-risk guideline means sizing the position so the loss at the stop (including fees/slippage allowance) is at most 1% of account equity; it does **not** mean using 1% margin.
- Run a substantial paper-trading sample and evaluate win rate, expectancy, profit factor, drawdown and signal frequency.
- No signal is financial advice or a promise of returns.
